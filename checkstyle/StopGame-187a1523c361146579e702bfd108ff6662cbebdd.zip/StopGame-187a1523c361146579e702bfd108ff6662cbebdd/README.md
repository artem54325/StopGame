# StopGame

<p align="center">
  <img width="460" height="720" src="https://user-images.githubusercontent.com/18012660/43095428-3cbb5d58-8ecf-11e8-8a19-6a7a9ae2fee8.png">
</p>

Данное приложение помогает следить за новостями на сайте stopgame.ru.

# Читать сайт стало удобнее с телефона теперь вы можете:
<li/>Читать журнал с приложения с телефона
<li/>Просматривать новости
<li/>Читать комментарии
<li/>Узнавать о начале трансляций
<li/>Просмотр информации об игре
<li/>И многое другое

# Что я сделал, чтобы это было возможно:
<li/>Написал парсер для TextView</li>
<li/>Написал класс для просмотра ютуба</li>
<p align="center">
  <img width="460" height="720" src="https://user-images.githubusercontent.com/18012660/43095379-10bf8198-8ecf-11e8-95b4-43bbab5f2614.png">
</p>
<li/>Парсер для меню, при добавлении на сайте новых рубрик, они будут отображаться в меню приложения</li>
<li/>Появляющийся список в меню, для удобного выбора</li>
<p align="center">
  <img width="460" height="720" src="https://user-images.githubusercontent.com/18012660/43095290-d5ca7976-8ece-11e8-9311-942b2a1595fd.png">
</p>
<li/>Удобное меню для просмотра дополнительной информациии об игре</li>
<p align="center">
  <img width="460" height="720" src="https://user-images.githubusercontent.com/18012660/43095411-2a6e4976-8ecf-11e8-95bf-f58454775b2f.png">
</p>
