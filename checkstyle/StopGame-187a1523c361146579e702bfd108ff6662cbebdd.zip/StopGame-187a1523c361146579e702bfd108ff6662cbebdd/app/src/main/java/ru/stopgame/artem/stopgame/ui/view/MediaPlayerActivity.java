package ru.stopgame.artem.stopgame.ui.view;

import android.support.v7.app.AppCompatActivity;



public class MediaPlayerActivity extends AppCompatActivity {
}
