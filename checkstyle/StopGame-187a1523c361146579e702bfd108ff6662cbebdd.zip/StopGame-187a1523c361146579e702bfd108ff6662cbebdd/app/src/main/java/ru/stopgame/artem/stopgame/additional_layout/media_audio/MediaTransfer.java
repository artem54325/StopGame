package ru.stopgame.artem.stopgame.additional_layout.media_audio;



public class MediaTransfer {
    private static String name=null;
    private static String url=null;

    public static String getName() {
        return name;
    }

    public static void setName(String name) {
        MediaTransfer.name = name;
    }

    public static String getUrl() {
        return url;
    }

    public static void setUrl(String url) {
        MediaTransfer.url = url;
    }
}
