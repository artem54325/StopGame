package ru.stopgame.artem.stopgame.models;


public class OnlineAnnouncer extends ImgAndUrl {}
