package ru.stopgame.artem.stopgame.ui;


public interface Presenter {
    void getHttp();
    void viewsPresent(final String html);
}
