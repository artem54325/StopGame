package ru.stopgame.artem.stopgame.ui;


import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.view.MenuItem;

public class Navigations implements NavigationView.OnNavigationItemSelectedListener {
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return true;
    }
}
