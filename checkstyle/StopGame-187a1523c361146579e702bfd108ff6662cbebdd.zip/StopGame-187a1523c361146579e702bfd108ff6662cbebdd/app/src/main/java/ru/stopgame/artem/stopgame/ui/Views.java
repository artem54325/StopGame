package ru.stopgame.artem.stopgame.ui;


import ru.stopgame.artem.stopgame.models.PostShow;

public interface Views {
    void views(PostShow object);
}
